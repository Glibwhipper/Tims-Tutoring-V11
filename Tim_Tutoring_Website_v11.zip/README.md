# Tim's Tutoring

An education-first browser website with Tim's step-by-step tutor plus optional hidden extras.

## Main features
- Tim's tutoring assistant
- Account creation/login
- Light/dark mode
- Custom background themes
- Calm generated background music
- Music search that opens YouTube results
- Optional breakdancing Fred the burger
- Hidden Central Messaging Board, Direct Messages, and Scrypter

## Run it
Open `index.html` in a modern browser.

## Notes
Accounts and messages are stored only in the browser's localStorage. This is a front-end demo, not a real internet-wide account or messaging service.

The calm background music is generated with Web Audio. Song search opens YouTube search results; the site does not download or host songs.


## v9 changes
- Replaced ZilchCoin with **Stonks**, a fictional virtual-credit community stock marketplace. Each account can create one stock. When another account buys a share, the creator receives that purchase price as virtual credits.
- Added a **Creator** badge to the `Glibwhipper` account and its posts/messages/stock listings.
- All Stonks balances and trades remain local to the browser; there are no real-money transactions.

- Added a delete option for each user's one Stonks listing; deleting also clears buyers' holdings in that stock.
