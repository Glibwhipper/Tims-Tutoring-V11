const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const keyUsers="tim_users", keyPosts="tim_posts", keyDM="tim_dm";
let currentUser=localStorage.getItem("tim_current")||null, authMode="signup", secretClicks=0, gameType="";

function users(){return JSON.parse(localStorage.getItem(keyUsers)||"[]")}
function posts(){return JSON.parse(localStorage.getItem(keyPosts)||"[]")}
function dms(){return JSON.parse(localStorage.getItem(keyDM)||"[]")}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function toast(t){let x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2200)}
function show(id){$$(".page").forEach(p=>p.classList.remove("active"));$("#"+id).classList.add("active");window.scrollTo({top:0,behavior:"smooth"});if(id==="board")renderBoard();if(id==="dm")renderInbox();if(id==="secret")renderSecret()}
function isCreator(u=currentUser){return String(u||"").toLowerCase()==="glibwhipper"}
function userRecord(name){return users().find(x=>x.name.toLowerCase()===String(name||"").toLowerCase())||null}
function avatarMarkup(name,large=false){const u=userRecord(name),pic=u?.avatar||"";return `<span class="avatar ${large?"avatar-large":""}" aria-label="${esc(name)}'s profile picture">${pic?`<img src="${pic}" alt="">`:`👤`}</span>`}
function roleBadge(u){return isCreator(u)?` <span class="role-badge">Creator</span>`:""}
function renderAccount(){let a=$("#accountArea");a.innerHTML=currentUser?`${avatarMarkup(currentUser)}<span class="hint">Hi, ${esc(currentUser)}!</span>${roleBadge()} <button id="logoutBtn" class="small-btn">Log out</button>`:`<button id="loginBtn" class="small-btn">Log in / Sign up</button>`;$("#loginBtn")?.addEventListener("click",openAuth);$("#logoutBtn")?.addEventListener("click",()=>{currentUser=null;localStorage.removeItem("tim_current");renderAccount();toast("Logged out.")})}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function openAuth(){authMode="signup";$("#modalTitle").textContent="Create an account";$("#modalSubtitle").textContent="You'll need an account to unlock the secret toolbox.";$("#authSubmit").textContent="Create account";$("#toggleAuth").textContent="Already have an account? Log in";$("#modal").classList.remove("hidden");$("#authError").textContent=""}
function closeAuth(){$("#modal").classList.add("hidden")}
$("#closeModal").onclick=closeAuth;
$("#toggleAuth").onclick=()=>{authMode=authMode==="signup"?"login":"signup";$("#modalTitle").textContent=authMode==="signup"?"Create an account":"Log in";$("#modalSubtitle").textContent=authMode==="signup"?"You'll need an account to unlock the secret toolbox.":"Welcome back!";$("#authSubmit").textContent=authMode==="signup"?"Create account":"Log in";$("#toggleAuth").textContent=authMode==="signup"?"Already have an account? Log in":"Need an account? Sign up"};
$("#authForm").onsubmit=e=>{e.preventDefault();let u=$("#username").value.trim(),p=$("#password").value,us=users(),found=us.find(x=>x.name.toLowerCase()===u.toLowerCase());if(authMode==="signup"){if(found)return $("#authError").textContent="That username is already taken.";us.push({name:u,password:p,avatar:""});save(keyUsers,us);toast("Account created!");}else{if(!found||found.password!==p)return $("#authError").textContent="Incorrect username or password.";u=found.name}currentUser=u;localStorage.setItem("tim_current",u);renderAccount();closeAuth();toast(`Welcome, ${u}!`)};

$("#logoBtn").onclick=()=>{secretClicks++;if(secretClicks>=3){secretClicks=0;if(!currentUser){openAuth()}else{show("secret");toast("Extra tools opened.")}}};
$("#startTutorBtn").onclick=()=>show("tutor");
$$(".backHome").forEach(b=>b.onclick=()=>show("home"));
$$(".backSecret").forEach(b=>b.onclick=()=>show("secret"));
$$(".tool-card").forEach(b=>b.onclick=()=>{if(!currentUser)return openAuth();show(b.dataset.page)});

function assistantAnswer(q){
 let s=q.toLowerCase().trim(), m;
 m=s.match(/(?:solve|what is|calculate)?\s*(-?\d+(?:\.\d+)?)\s*([+\-*x×÷/])\s*(-?\d+(?:\.\d+)?)/i);
 if(m){let a=+m[1],op=m[2],b=+m[3];return `Let's solve this step by step without giving away the final answer:<br><br><b>Step 1:</b> Identify the two numbers: ${a} and ${b}.<br><b>Step 2:</b> Identify the operation symbol <b>${op}</b>. This tells you whether to add, subtract, multiply, or divide.<br><b>Step 3:</b> Set up the calculation: <b>${a} ${op} ${b}</b>.<br><b>Step 4:</b> Do the operation carefully. Work it out yourself, then check that your result makes sense.<br><br>💡 <b>Your turn:</b> What number do you get? I won't reveal the final answer because the goal is for you to learn how to solve it.`;}
 m=s.match(/solve\s+(-?\d*\.?\d*)x\s*([+-])\s*(-?\d+(?:\.\d+)?)\s*=\s*(-?\d+(?:\.\d+)?)/i);
 if(m){let a=parseFloat(m[1]||"1"),b=parseFloat(m[3]),c=parseFloat(m[4]);return `Let's solve this equation step by step without revealing x:<br><br><b>Step 1:</b> Start with <b>${a}x ${m[2]} ${b} = ${c}</b>.<br><b>Step 2:</b> Your goal is to get <b>x</b> by itself.<br><b>Step 3:</b> Move the constant term (${b}) to the other side. Use the opposite operation: if it is added, subtract it; if it is subtracted, add it.<br><b>Step 4:</b> After moving the constant, you should have a number multiplied by <b>x</b> on one side and a simplified number on the other.<br><b>Step 5:</b> Divide both sides by the number multiplying x.<br><br>💡 <b>Your turn:</b> Finish those calculations to find x. If you show me your work, I can help you check the next step without giving away the answer.`;}
 if(/photosynthesis/.test(s))return `<b>How to understand photosynthesis:</b><br><br><b>Step 1:</b> Identify what plants need: light energy, water, and carbon dioxide.<br><b>Step 2:</b> Remember that chloroplasts are the cell structures where this process happens.<br><b>Step 3:</b> Think about what the plant makes. It produces a sugar that stores chemical energy and releases oxygen.<br><b>Step 4:</b> Put the inputs and outputs together into the overall process.<br><br>💡 Try writing the process in your own words. I can help you check whether your explanation is complete.`;
 if(/mitochond/.test(s))return `<b>Let's reason it out:</b><br><br><b>Step 1:</b> Ask what part of a cell is responsible for helping release usable energy from food.<br><b>Step 2:</b> Think about the organelle commonly associated with cellular energy production.<br><b>Step 3:</b> Connect that organelle to cellular respiration, where energy stored in food is made more usable by the cell.<br><br>💡 Try naming the organelle yourself. If you're unsure, tell me what you think and I'll guide you.`;
 if(/gravity/.test(s))return `<b>Let's work through the idea:</b><br><br><b>Step 1:</b> Remember that gravity is a force associated with objects that have mass.<br><b>Step 2:</b> Ask what gravity does to objects near Earth.<br><b>Step 3:</b> Connect that force to why objects fall toward the ground.<br><b>Step 4:</b> If you're working with a physics calculation, identify the object's mass and the appropriate gravitational acceleration before calculating.<br><br>💡 Explain gravity in your own words, and I can help you improve your explanation.`;
 if(/area.*triangle|triangle.*area/.test(s))return `<b>Let's find the area step by step:</b><br><br><b>Step 1:</b> Identify the triangle's base and height.<br><b>Step 2:</b> Multiply the base by the height.<br><b>Step 3:</b> Take that result and divide it by 2.<br><b>Step 4:</b> Include square units in your final result.<br><br>💡 Do those calculations yourself and send me your work. I can check each step without simply giving you the answer.`;
 return `I can guide you through it without giving away the answer. Start by identifying exactly what the problem is asking you to find, then list the information you're given. Next, choose the rule, formula, or concept that connects the given information to what you're trying to find. Work through one step at a time and simplify as you go.<br><br>💡 Send me the exact problem and I'll give you a detailed step-by-step path to solve it.`;
}

$("#chatForm").onsubmit=e=>{e.preventDefault();let q=$("#problemInput").value.trim();if(!q)return;$("#chatMessages").insertAdjacentHTML("beforeend",`<div class="msg user"><b>You</b><p>${esc(q)}</p></div>`);let a=assistantAnswer(q);setTimeout(()=>{$("#chatMessages").insertAdjacentHTML("beforeend",`<div class="msg assistant"><b>Tim</b><p>${a}</p></div>`);$("#chatMessages").scrollTop=$("#chatMessages").scrollHeight},250);$("#problemInput").value=""};

function renderSecret(){if(!currentUser){$("#toolGrid").classList.add("hidden");$("#lockedNotice").classList.remove("hidden");$("#lockedNotice").textContent="Log in to use these extra tools."}else{$("#toolGrid").classList.remove("hidden");$("#lockedNotice").classList.add("hidden")}}
$("#boardForm").onsubmit=e=>{e.preventDefault();if(!currentUser)return openAuth();let p=posts();p.unshift({id:Date.now(),title:$("#boardTitle").value,text:$("#boardText").value,user:currentUser,time:new Date().toLocaleString()});save(keyPosts,p);e.target.reset();renderBoard();toast("Posted to the Central Board!")};
function renderBoard(){let p=posts();$("#boardPosts").innerHTML=p.length?p.map(x=>`<article class="post"><h3>${esc(x.title)}</h3><div class="post-meta post-author">${avatarMarkup(x.user)}<span>by ${esc(x.user)}${isCreator(x.user)?roleBadge(x.user):""} • ${esc(x.time)}</span></div><div>${esc(x.text).replace(/\n/g,"<br>")}</div></article>`).join(""):`<div class="panel"><h3>No posts yet</h3><p class="hint">Be the first person to post!</p></div>`}
$("#dmForm").onsubmit=e=>{e.preventDefault();if(!currentUser)return openAuth();let to=$("#dmTo").value.trim(),u=users().find(x=>x.name.toLowerCase()===to.toLowerCase());if(!u)return toast("That user doesn't exist on this browser.");let a=dms();a.unshift({from:currentUser,to:u.name,text:$("#dmText").value,time:new Date().toLocaleString()});save(keyDM,a);e.target.reset();renderInbox();toast("Message sent!")};
function renderInbox(){let arr=dms().filter(x=>x.to.toLowerCase()===currentUser?.toLowerCase());$("#inbox").innerHTML=arr.length?arr.map(x=>`<div class="inbox-item"><div class="post-author">${avatarMarkup(x.from)}<b>${esc(x.from)}${roleBadge(x.from)}</b><small> • ${esc(x.time)}</small></div><p>${esc(x.text)}</p></div>`).join(""):`<p class="hint">Your inbox is empty.</p>`}

const canvas=$("#gameCanvas"),ctx=canvas.getContext("2d");let loop=null,state=null;
function generateGame(){let p=$("#gamePrompt").value.trim().toLowerCase();if(!p)return toast("Describe a game first!");if(loop)cancelAnimationFrame(loop);if(/snake/.test(p))gameType="snake";else if(/click|coin|idle/.test(p))gameType="clicker";else if(/platform|jump/.test(p))gameType="platformer";else gameType="dodge";state={score:0,over:false,keys:{},last:performance.now(),items:[],player:{x:canvas.width/2,y:canvas.height-45,w:28,h:28,vy:0}};$("#gameTitle").textContent=gameType==="clicker"?"Coin Clicker":gameType==="platformer"?"Jump Quest":gameType==="snake"?"Snake Scrypter":"Asteroid Dodge";$("#gameStatus").textContent="Generated!";$("#gameInstructions").textContent=gameType==="clicker"?"Click the canvas to collect coins.":gameType==="platformer"?"Use ← → to move and Space to jump.":"Use ← → or A/D to move. Avoid the falling objects.";requestAnimationFrame(gameLoop)}
function spawn(){if(Math.random()<.035)state.items.push({x:20+Math.random()*(canvas.width-40),y:-25,w:24,h:24,vy:2+Math.random()*3})}
function gameLoop(t){let dt=Math.min(32,t-state.last);state.last=t;ctx.clearRect(0,0,canvas.width,canvas.height);if(gameType==="clicker")drawClicker();else if(gameType==="platformer")drawPlatformer(dt);else drawDodge(dt);$("#gameScore").textContent="Score: "+Math.floor(state.score);if(!state.over)loop=requestAnimationFrame(gameLoop)}
function drawDodge(dt){ctx.fillStyle="#101525";ctx.fillRect(0,0,canvas.width,canvas.height);let p=state.player;if(state.keys.ArrowLeft||state.keys.a)p.x-=5;if(state.keys.ArrowRight||state.keys.d)p.x+=5;p.x=Math.max(15,Math.min(canvas.width-15,p.x));spawn();state.items.forEach(o=>{o.y+=o.vy*dt/8;ctx.fillStyle="#ff6b6b";ctx.beginPath();ctx.arc(o.x,o.y,12,0,Math.PI*2);ctx.fill()});state.items=state.items.filter(o=>o.y<canvas.height+30);state.items.forEach(o=>{if(Math.abs(o.x-p.x)<25&&Math.abs(o.y-p.y)<25)endGame()});ctx.fillStyle="#6c5ce7";ctx.fillRect(p.x-14,p.y-14,28,28);state.score+=dt/100;drawStars()}
function drawStars(){ctx.fillStyle="#fff";for(let i=0;i<45;i++){let x=(i*83)%canvas.width,y=(i*47)%canvas.height;ctx.fillRect(x,y,2,2)}}
function drawPlatformer(dt){ctx.fillStyle="#bfe8ff";ctx.fillRect(0,0,canvas.width,canvas.height);let p=state.player;p.vy+=.45;if(state.keys.ArrowLeft||state.keys.a)p.x-=4;if(state.keys.ArrowRight||state.keys.d)p.x+=4;if(state.keys[" "]&&p.y>=canvas.height-70)p.vy=-10;p.y+=p.vy;if(p.y>canvas.height-70){p.y=canvas.height-70;p.vy=0}ctx.fillStyle="#6c5ce7";ctx.fillRect(0,canvas.height-35,canvas.width,35);ctx.fillStyle="#ffb84d";ctx.fillRect(p.x-15,p.y-15,30,30);spawn();state.items.forEach(o=>{o.y+=o.vy*dt/8;ctx.fillStyle="#e74c3c";ctx.fillRect(o.x-12,o.y-12,24,24);if(Math.abs(o.x-p.x)<25&&Math.abs(o.y-p.y)<25)endGame()});state.items=state.items.filter(o=>o.y<canvas.height);state.score+=dt/100;$("#gameInstructions").textContent="← → / A D to move • Space to jump"}
function drawClicker(){ctx.fillStyle="#151b2e";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#ffd166";ctx.beginPath();ctx.arc(canvas.width/2,canvas.height/2,70,0,Math.PI*2);ctx.fill();ctx.fillStyle="#172033";ctx.font="bold 24px system-ui";ctx.textAlign="center";ctx.fillText("CLICK!",canvas.width/2,canvas.height/2+8);ctx.fillStyle="#fff";ctx.font="18px system-ui";ctx.fillText("Coins: "+Math.floor(state.score),canvas.width/2,45)}
function endGame(){state.over=true;ctx.fillStyle="#172033cc";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#fff";ctx.textAlign="center";ctx.font="bold 38px system-ui";ctx.fillText("Game Over!",canvas.width/2,canvas.height/2);ctx.font="18px system-ui";ctx.fillText("Generate again to restart.",canvas.width/2,canvas.height/2+38)}
canvas.onclick=()=>{canvas.focus();if(gameType==="clicker"){state.score+=1;drawClicker()}};
window.addEventListener("keydown",e=>{
  const activePage=$("#scrypter")?.classList.contains("active");
  const typing=["INPUT","TEXTAREA"].includes(document.activeElement?.tagName);
  const gameFocused=document.activeElement===canvas;
  if(activePage && gameFocused && ["ArrowLeft","ArrowRight"," "].includes(e.key)) e.preventDefault();
  if(state && activePage && !typing && gameFocused) state.keys[e.key]=true;
});
window.addEventListener("keyup",e=>{
  const activePage=$("#scrypter")?.classList.contains("active");
  const typing=["INPUT","TEXTAREA"].includes(document.activeElement?.tagName);
  const gameFocused=document.activeElement===canvas;
  if(state && activePage && !typing && gameFocused) state.keys[e.key]=false;
});
$("#generateGameBtn").onclick=generateGame;
renderAccount();renderSecret();
// Optional extras: music, appearance settings, and the intentionally ridiculous Fred burger.
const settingsBtn = $("#settingsBtn");
const settingsModal = $("#settingsModal");
const musicFab = $("#musicFab");
const musicModal = $("#musicModal");
const fredBurger = $("#fredBurger");

function getCurrentUserRecord(){return currentUser?userRecord(currentUser):null}
function renderProfileEditor(){
  const u=getCurrentUserRecord(), preview=$("#profilePreview"), remove=$("#removeProfilePicture");
  if(!preview)return;
  const pic=u?.avatar||"";
  preview.innerHTML=pic?`<img src="${pic}" alt="Your profile picture">`:`👤`;
  remove.disabled=!pic;
  $("#profilePictureStatus").textContent=currentUser?"":"Log in to choose a profile picture.";
}
function saveAvatar(dataUrl){
  if(!currentUser)return;
  const us=users(), idx=us.findIndex(x=>x.name.toLowerCase()===currentUser.toLowerCase());
  if(idx<0)return;
  us[idx].avatar=dataUrl;
  try{save(keyUsers,us);renderAccount();renderBoard();renderInbox();renderStocks();renderProfileEditor();toast("Profile picture updated!")}
  catch(err){$("#profilePictureStatus").textContent="That picture could not be saved. Try a smaller image."}
}
$("#profilePictureInput")?.addEventListener("change",e=>{
  const file=e.target.files?.[0]; if(!file)return;
  const status=$("#profilePictureStatus");
  if(!file.type.startsWith("image/")){status.textContent="Please choose an image file.";e.target.value="";return}
  const reader=new FileReader();
  reader.onload=()=>{
    const img=new Image();
    img.onload=()=>{
      const max=256, scale=Math.min(1,max/Math.max(img.width,img.height));
      const canvas=document.createElement("canvas"); canvas.width=Math.max(1,Math.round(img.width*scale)); canvas.height=Math.max(1,Math.round(img.height*scale));
      const ctx=canvas.getContext("2d"); ctx.drawImage(img,0,0,canvas.width,canvas.height);
      saveAvatar(canvas.toDataURL("image/jpeg",.82)); e.target.value="";
    };
    img.onerror=()=>{status.textContent="That image could not be read."}; img.src=reader.result;
  };
  reader.onerror=()=>status.textContent="Could not read that file."; reader.readAsDataURL(file);
});
$("#removeProfilePicture")?.addEventListener("click",()=>{if(!currentUser)return;saveAvatar("");toast("Profile picture removed.")});

function applyAppearance(){
  const mode=localStorage.getItem("tim_mode")||"light";
  const theme=localStorage.getItem("tim_theme")||"default";
  document.body.classList.remove("dark","theme-default","theme-axolotl","theme-trees","theme-river","theme-turtle","theme-kitten");
  document.body.classList.add("theme-"+theme);
  document.body.classList.toggle("dark",mode==="dark");
  $$(`[data-mode]`).forEach(b=>b.classList.toggle("selected",b.dataset.mode===mode));
  $$(`[data-theme]`).forEach(b=>b.classList.toggle("selected",b.dataset.theme===theme));
  $("#fredToggle").checked=localStorage.getItem("tim_fred")==="on";
  fredBurger.classList.toggle("hidden",localStorage.getItem("tim_fred")!=="on");
}
settingsBtn.onclick=()=>settingsModal.classList.remove("hidden");
$("#closeSettings").onclick=()=>settingsModal.classList.add("hidden");
$$("[data-mode]").forEach(b=>b.onclick=()=>{localStorage.setItem("tim_mode",b.dataset.mode);applyAppearance();toast(`${b.dataset.mode} mode enabled.`)});
$$("[data-theme]").forEach(b=>b.onclick=()=>{localStorage.setItem("tim_theme",b.dataset.theme);applyAppearance();toast("Background changed!")});
$("#fredToggle").onchange=e=>{localStorage.setItem("tim_fred",e.target.checked?"on":"off");applyAppearance()};

// Calm background music made entirely with Web Audio, so the site needs no audio file.
let audioCtx=null, musicTimer=null, musicPlaying=false, musicStep=0;
function startCalmMusic(){
  if(musicPlaying)return;
  audioCtx=new (window.AudioContext||window.webkitAudioContext)();
  musicPlaying=true; musicStep=0;
  const notes=[261.63,329.63,392.00,329.63,293.66,349.23,440.00,349.23];
  const tick=()=>{
    if(!musicPlaying)return;
    const osc=audioCtx.createOscillator(), gain=audioCtx.createGain();
    osc.type="sine"; osc.frequency.value=notes[musicStep%notes.length];
    gain.gain.setValueAtTime(0,audioCtx.currentTime);gain.gain.linearRampToValueAtTime(.035,audioCtx.currentTime+.08);gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+1.7);
    osc.connect(gain).connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+1.8);
    musicStep++;musicTimer=setTimeout(tick,1200);
  }; tick();
  $("#musicToggle").textContent="⏸ Pause calm music";$("#musicState").textContent="Calm music is playing";
}
function stopCalmMusic(){musicPlaying=false;clearTimeout(musicTimer);if(audioCtx){audioCtx.close();audioCtx=null}$("#musicToggle").textContent="▶ Play calm music";$("#musicState").textContent="Music is off"}
musicFab.onclick=()=>musicModal.classList.remove("hidden");
$("#closeMusic").onclick=()=>musicModal.classList.add("hidden");
$("#musicToggle").onclick=()=>musicPlaying?stopCalmMusic():startCalmMusic();
$("#songSearchForm").onsubmit=e=>{
  e.preventDefault();
  const q=$("#songSearch").value.trim();
  if(!q)return;
  const wrap=$("#musicPlayerWrap"), player=$("#musicPlayer");
  player.src="https://www.youtube.com/embed?listType=search&list="+encodeURIComponent(q)+"&autoplay=1";
  wrap.classList.remove("hidden");
  $("#musicState").textContent="Playing search results for: "+q;
};

applyAppearance();
renderProfileEditor();

// Stonks: a fictional community stock marketplace using virtual credits only.
const stockKey="tim_stonks", cashKey="tim_stonk_cash", holdingsKey="tim_stonk_holdings";
function stocks(){return JSON.parse(localStorage.getItem(stockKey)||"[]")}
function saveStocks(v){localStorage.setItem(stockKey,JSON.stringify(v))}
function stonkCash(){if(!currentUser)return 10000;const all=JSON.parse(localStorage.getItem(cashKey)||"{}");return Number.isFinite(all[currentUser])?all[currentUser]:10000}
function saveStonkCash(v){const all=JSON.parse(localStorage.getItem(cashKey)||"{}");all[currentUser]=v;localStorage.setItem(cashKey,JSON.stringify(all))}
function stonkHoldings(){if(!currentUser)return {};const all=JSON.parse(localStorage.getItem(holdingsKey)||"{}");return all[currentUser]||{}}
function saveStonkHoldings(v){const all=JSON.parse(localStorage.getItem(holdingsKey)||"{}");all[currentUser]=v;localStorage.setItem(holdingsKey,JSON.stringify(all))}
function renderMyStock(){
 const mine=stocks().find(x=>x.creator.toLowerCase()===currentUser.toLowerCase());
 const card=$("#myStockCard"); if(!card)return;
 if(!mine){card.classList.add("hidden");return}
 card.classList.remove("hidden");card.innerHTML=`<div class="stock-card-head"><div><b>${esc(mine.name)}</b> <span class="ticker">${esc(mine.ticker)}</span></div><span class="role-badge">Your Stock</span></div><p>${mine.price.toFixed(2)} credits/share • ${mine.remaining.toLocaleString()} of ${mine.supply.toLocaleString()} shares left</p><p class="hint">Creator earnings: <b>${mine.earnings.toFixed(2)} virtual credits</b></p><button class="danger-btn stock-delete" data-id="${mine.id}">🗑️ Delete my stock</button><p class="delete-warning">Deleting removes this stock from the marketplace and clears any shares other users own in it. Your virtual earnings already received stay in your balance.</p>`;
 card.querySelector(".stock-delete").onclick=()=>deleteStock(mine.id);
}
function renderStocks(){
 if(!currentUser)return;
 $("#stonkCash").textContent=`$${stonkCash().toFixed(2)}`;
 renderMyStock();
 const list=$("#stockMarketList"),arr=stocks(),h=stonkHoldings();
 if(!arr.length){list.innerHTML=`<p class="hint">No community stocks yet. Be the first person to make one!</p>`;return}
 list.innerHTML=arr.map(st=>{const owned=h[st.id]||0;const mine=st.creator.toLowerCase()===currentUser.toLowerCase();return `<div class="stock-card"><div class="stock-card-head"><div><b>${esc(st.name)}</b> <span class="ticker">${esc(st.ticker)}</span></div><span class="stock-price">$${st.price.toFixed(2)}</span></div><p>Created by <b>${esc(st.creator)}</b>${isCreator(st.creator)?roleBadge(st.creator):""}</p><div class="stock-meta"><span>${st.remaining.toLocaleString()} left</span><span>You own: ${owned}</span></div><button class="primary-btn stock-buy" data-id="${st.id}" ${mine||st.remaining<1?"disabled":""}>${mine?"Your stock":st.remaining<1?"Sold out":`Buy 1 share ($${st.price.toFixed(2)})`}</button></div>`}).join("");
 list.querySelectorAll(".stock-buy").forEach(b=>b.onclick=()=>buyStock(b.dataset.id));
}
function createStock(e){
 e.preventDefault();if(!currentUser)return openAuth();
 const status=$("#stockCreateStatus"),arr=stocks();
 if(arr.some(x=>x.creator.toLowerCase()===currentUser.toLowerCase())){status.textContent="You already created your one stock.";renderMyStock();return}
 const name=$("#stockName").value.trim(),ticker=$("#stockTicker").value.trim().toUpperCase(),price=Number($("#stockPrice").value),supply=Math.floor(Number($("#stockSupply").value));
 if(name.length<2)return status.textContent="Give your stock a longer name.";
 if(!/^[A-Z0-9]{1,6}$/.test(ticker))return status.textContent="Ticker must be 1–6 letters or numbers.";
 if(!Number.isFinite(price)||price<1||price>1000)return status.textContent="Price must be between 1 and 1000 virtual credits.";
 if(!Number.isFinite(supply)||supply<1||supply>10000)return status.textContent="Shares must be between 1 and 10,000.";
 if(arr.some(x=>x.ticker===ticker))return status.textContent="That ticker is already taken.";
 arr.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),name,ticker,price,supply,remaining:supply,creator:currentUser,earnings:0,created:new Date().toISOString()});saveStocks(arr);$("#stockCreateForm").reset();status.textContent="Stock created! Let the stonks begin.";toast(`${name} is now on the exchange!`);renderStocks();
}
function buyStock(id){
 if(!currentUser)return openAuth();const arr=stocks(),st=arr.find(x=>x.id===id);if(!st)return;
 if(st.creator.toLowerCase()===currentUser.toLowerCase())return toast("You can't buy your own stock.");
 if(st.remaining<1)return toast("That stock is sold out.");
 const cash=stonkCash();if(cash<st.price)return toast("Not enough virtual credits.");
 const h=stonkHoldings();h[id]=(h[id]||0)+1;st.remaining-=1;st.earnings+=st.price;
 saveStonkCash(cash-st.price);
 const creatorCashAll=JSON.parse(localStorage.getItem(cashKey)||"{}");creatorCashAll[st.creator]=(Number.isFinite(creatorCashAll[st.creator])?creatorCashAll[st.creator]:10000)+st.price;localStorage.setItem(cashKey,JSON.stringify(creatorCashAll));
 saveStonkHoldings(h);saveStocks(arr);toast(`Bought 1 ${st.ticker} share. ${st.creator} earned ${st.price.toFixed(2)} virtual credits!`);renderStocks();
}
function deleteStock(id){
 if(!currentUser)return openAuth();
 const arr=stocks(),st=arr.find(x=>x.id===id);
 if(!st||st.creator.toLowerCase()!==currentUser.toLowerCase())return toast("You can only delete your own stock.");
 if(!confirm(`Delete ${st.name}? This removes it from the marketplace and clears all shares other users own.`))return;
 saveStocks(arr.filter(x=>x.id!==id));
 const all=JSON.parse(localStorage.getItem(holdingsKey)||"{}");
 Object.keys(all).forEach(u=>{if(all[u])delete all[u][id]});
 localStorage.setItem(holdingsKey,JSON.stringify(all));
 $("#stockCreateForm")?.reset();
 $("#stockCreateStatus").textContent="Your stock was deleted. You can create a new one.";
 toast(`${st.name} was deleted.`);
 renderStocks();
}

$("#stockCreateForm")?.addEventListener("submit",createStock);
const oldShow=show;show=function(id){oldShow(id);if(id==="stonks")renderStocks()};

